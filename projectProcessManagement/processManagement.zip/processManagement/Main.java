package processManagement;

public class Main {

	public static void main(String[] args) {
		Queue<Integer> cola = new LinkedQueue<>();

	}
}
